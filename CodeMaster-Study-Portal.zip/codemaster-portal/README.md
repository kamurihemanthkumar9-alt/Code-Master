# CodeMaster Study Portal

A responsive, browser-based learning portal with syllabus browsing, reading notes, practice quizzes, timed mock tests and progress tracking.

## Files
- `index.html` — page structure
- `style.css` — responsive visual design
- `app.js` — syllabus, notes, quizzes, mock-test engine and local progress

## Run in VS Code
1. Extract the ZIP.
2. Open the `codemaster-portal` folder in VS Code.
3. Install the **Live Server** extension if needed.
4. Open `index.html`, right-click and choose **Open with Live Server**.
5. Keep all three files in the same folder.

You can also open `index.html` directly in a browser, but Live Server is recommended.

## Features
- 10 sample subject outlines with units and topics
- Topic completion tracker
- Subject search and level filter
- Built-in reading notes and examples
- Subject practice quizzes with explanations
- Timed mock tests with question navigation and result report
- Local dashboard, progress report and mock-test history
- Dark mode and mobile navigation
- Display name can be changed locally

## Important syllabus note
This is a general starter curriculum, not the official complete syllabus of every school board, intermediate board or university. The Engineering Mathematics, Physics and Chemistry outlines are generic first-year examples. Before using it for exams, edit the `subjects` array in `app.js` to match your exact board, university, branch, regulation and semester. Add your own authorised notes, question banks and course materials.

## Login and cloud access
This version uses a local demo profile and browser `localStorage`. It does not provide real secure accounts, cross-device sync, teacher/admin access or a private database. Those require a backend such as Supabase or Firebase with authentication, database rules and security configuration. Never store passwords in localStorage.

## Publishing
The project is static and can be deployed to GitHub Pages, Netlify or Vercel. Since progress is local, each browser/device has its own saved progress until a backend is connected.
