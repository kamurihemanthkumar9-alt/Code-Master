/* CodeMaster Study Portal
   Front-end learning portal. Progress, quiz scores and profile are stored in this browser.
   Replace the sample syllabus with your exact board/university curriculum before publishing. */
const subjects = [
{id:"c",name:"C Programming",level:"College",category:"Programming",symbol:"C",color:"#596b91",desc:"Problem solving, C syntax, control flow, functions, arrays, pointers and files.",units:[
["Programming fundamentals",["Problem solving and algorithms","Flowcharts and pseudocode","Structure of a C program","Compiler, linker and execution","Tokens, keywords and identifiers"]],
["Data types and operators",["Constants and variables","Primitive data types","Input and output using printf and scanf","Arithmetic, relational and logical operators","Type conversion and expressions"]],
["Decision making and loops",["if and if-else statements","Nested if and else-if ladder","switch statement","while and do-while loops","for loop, break and continue"]],
["Functions and collections",["Function declaration and definition","Arguments, return values and recursion","One-dimensional and two-dimensional arrays","Strings and string library functions","Pointers, structures and file handling"]]
]},
{id:"python",name:"Python Programming",level:"Programming",category:"Programming",symbol:"Py",color:"#438f9c",desc:"Python basics, collections, functions, modules, files and object-oriented programming.",units:[
["Python foundations",["Installing Python and running a program","Syntax, indentation and comments","Variables and built-in data types","Input, output and type conversion","Operators and expressions"]],
["Control flow",["if, elif and else","for and while loops","range, break and continue","Nested loops","Basic problem-solving patterns"]],
["Collections and functions",["Strings and string methods","Lists and list operations","Tuples, sets and dictionaries","Defining and calling functions","Parameters, return values and scope"]],
["Beyond the basics",["Modules and packages","Reading and writing files","Exception handling","Classes and objects","Inheritance and introductory OOP"]]
]},
{id:"htmlcss",name:"HTML & CSS",level:"Programming",category:"Web development",symbol:"{ }",color:"#df8555",desc:"Create accessible web pages with semantic HTML, modern CSS and responsive layouts.",units:[
["HTML structure",["HTML document structure","Headings, paragraphs and text formatting","Links, images and paths","Lists, tables and semantic elements","Forms, labels and input types"]],
["CSS foundations",["CSS syntax and selectors","Colors, fonts and units","Cascade, specificity and inheritance","Box model, margin and padding","Borders, backgrounds and shadows"]],
["Layout and responsive design",["Display and positioning","Flexbox","CSS Grid","Media queries and responsive units","Mobile-first design"]],
["Accessible web pages",["Semantic landmarks","Accessible forms and labels","Image alternative text","Keyboard navigation basics","Page structure and validation"]]
]},
{id:"javascript",name:"JavaScript",level:"Programming",category:"Web development",symbol:"JS",color:"#c49b39",desc:"Build interactive websites using JavaScript fundamentals, functions, DOM and browser APIs.",units:[
["Language basics",["Adding JavaScript to a web page","let, const and variables","Primitive data types","Operators and expressions","Strings and template literals"]],
["Logic and reusable code",["if, else and switch","for, while and for...of loops","Functions and arrow functions","Arrays and array methods","Objects and JSON"]],
["Browser interaction",["DOM selection and modification","Events and event listeners","Form validation","Local storage","Debugging with browser developer tools"]],
["Modern JavaScript",["Scope and callbacks","Promises and async/await","Fetch API basics","Modules and imports","Building a small interactive project"]]
]},
{id:"math",name:"Engineering Mathematics I",level:"College",category:"Mathematics",symbol:"∑",color:"#7968bd",desc:"A general first-year engineering mathematics outline; align topics to your university scheme.",units:[
["Matrices",["Types of matrices and operations","Determinants","Rank of a matrix","System of linear equations","Eigenvalues and eigenvectors"]],
["Differential calculus",["Limits and continuity","Differentiation rules","Successive differentiation","Taylor and Maclaurin series","Partial derivatives"]],
["Integral calculus",["Indefinite integration","Definite integrals","Integration by substitution and parts","Reduction formulae","Applications of integration"]],
["Differential equations",["Order and degree","First-order differential equations","Linear differential equations","Higher-order linear equations","Engineering applications"]]
]},
{id:"physics",name:"Engineering Physics",level:"College",category:"Science",symbol:"Φ",color:"#438baf",desc:"Common introductory engineering physics topics; verify the unit list against your syllabus.",units:[
["Waves and oscillations",["Simple harmonic motion","Damped oscillations","Forced oscillations and resonance","Wave motion","Ultrasonics and applications"]],
["Optics and lasers",["Interference of light","Diffraction","Polarization","Laser principles","Optical fibre fundamentals"]],
["Electricity and magnetism",["Electric fields and potential","Magnetic fields","Electromagnetic induction","Maxwell equation overview","Electromagnetic waves"]],
["Modern physics",["Introduction to quantum ideas","Wave-particle duality","Schrodinger equation overview","Semiconductors","Nanomaterials and applications"]]
]},
{id:"chemistry",name:"Engineering Chemistry",level:"College",category:"Science",symbol:"⚗",color:"#3c9c82",desc:"A general engineering chemistry foundation covering materials, water, energy and corrosion.",units:[
["Water technology",["Hardness of water","Water softening methods","Boiler troubles","Desalination","Water quality parameters"]],
["Electrochemistry and corrosion",["Electrochemical cells","Electrode potential","Batteries and fuel cells","Types of corrosion","Corrosion prevention"]],
["Materials chemistry",["Polymers and classifications","Conducting polymers","Nanomaterials","Composite materials","Smart materials"]],
["Energy and environment",["Fuels and calorific value","Combustion basics","Green chemistry principles","Air and water pollution","Sustainable technologies"]]
]},
{id:"computer",name:"Computer Fundamentals",level:"School",category:"Computer science",symbol:"PC",color:"#697d9b",desc:"Understand hardware, software, number systems, data representation and computer networks.",units:[
["Computer basics",["Characteristics and generations of computers","Functional units of a computer","Input and output devices","Hardware and software","Operating system overview"]],
["Data representation",["Binary, decimal, octal and hexadecimal","Number-system conversions","Binary arithmetic","Signed number representations","ASCII and Unicode"]],
["Memory and storage",["Primary and secondary memory","RAM and ROM","Cache memory","Storage devices","Units of data"]],
["Networks and internet",["Network types and topologies","Internet and web basics","IP address and DNS overview","Cyber safety and privacy basics","Cloud computing introduction"]]
]},
{id:"dbms",name:"DBMS & SQL",level:"College",category:"Computer science",symbol:"DB",color:"#ba7958",desc:"Database concepts, relational models, SQL queries, joins, constraints and transactions.",units:[
["Database foundations",["Data, information and databases","DBMS architecture","Database users and schema","Relational model","Keys and integrity constraints"]],
["SQL essentials",["CREATE, ALTER and DROP","INSERT, UPDATE and DELETE","SELECT and WHERE","ORDER BY and GROUP BY","Aggregate functions"]],
["Relational operations",["Primary and foreign keys","Joins: inner, left, right","Subqueries","Views and indexes","Normalization: 1NF, 2NF and 3NF"]],
["Transactions",["ACID properties","Transaction states","Concurrency overview","Database backup concepts","Basic database security"]]
]},
{id:"english",name:"Communication Skills",level:"Intermediate",category:"Language",symbol:"Aa",color:"#bd7291",desc:"Develop grammar, reading, writing, listening, speaking and presentation skills.",units:[
["Grammar essentials",["Parts of speech","Tenses","Subject-verb agreement","Articles and prepositions","Sentence types and punctuation"]],
["Reading and vocabulary",["Skimming and scanning","Finding main ideas","Context clues","Summarising a passage","Building academic vocabulary"]],
["Writing skills",["Paragraph writing","Formal letters and emails","Reports and summaries","Resume basics","Common writing errors"]],
["Speaking and listening",["Self-introduction","Group discussion","Situation dialogues","Presentation structure","Active listening and feedback"]]
]}
];

const materials = [
{subject:"c",title:"C program structure and first program",summary:"A C program starts execution from main().",sections:[["Basic structure","A C source file commonly includes header files, a main() function, declarations, executable statements and a return statement. The compiler translates source code into an executable program."],["Example",'#include <stdio.h>\nint main(void) {\n    printf("Hello, world!\\n");\n    return 0;\n}'],["Remember","stdio.h provides standard input/output declarations. printf() displays output. The semicolon ends a statement. Braces group a function body."]]},
{subject:"c",title:"Decision statements in C",summary:"Choose a path using if, else-if and switch.",sections:[["if and else","An if statement executes a block when its condition is true. An else block runs when the condition is false."],["Example",'int age = 18;\nif (age >= 18) {\n    printf("Eligible");\n} else {\n    printf("Not eligible");\n}'],["else-if ladder","Use else-if when several conditions must be checked in order. The first true condition's block runs; otherwise the optional final else block runs."]]},
{subject:"python",title:"Python variables and data types",summary:"Variables refer to values; Python infers the type.",sections:[["Variables","A variable is a name that refers to a value. Python uses assignment with = and does not require a separate type declaration."],["Example",'name = "Asha"\nage = 18\nmarks = 92.5\nis_student = True\nprint(name, age, marks, is_student)'],["Common types","int represents integers, float represents decimal numbers, str represents text and bool represents True or False. Use type(value) to inspect a value's type."]]},
{subject:"python",title:"Python conditional statements",summary:"Use if, elif and else to make decisions.",sections:[["Conditions","A condition evaluates to True or False. Comparison operators include ==, !=, <, >, <= and >=."],["Example",'marks = 76\nif marks >= 90:\n    grade = "A"\nelif marks >= 60:\n    grade = "B"\nelse:\n    grade = "C"\nprint(grade)'],["Indentation","Indentation defines a code block in Python. Keep the indentation consistent, commonly four spaces."]]},
{subject:"htmlcss",title:"HTML document structure",summary:"HTML gives a web page its content and meaning.",sections:[["Core elements","The doctype declares HTML5. The html element wraps the document. The head contains metadata and linked resources. The body contains visible page content."],["Example",'<!doctype html>\n<html lang="en">\n<head><meta charset="UTF-8"><title>My page</title></head>\n<body><h1>Hello</h1><p>My first page.</p></body>\n</html>'],["Semantic HTML","Use elements such as header, nav, main, section, article and footer according to their meaning. Semantic structure helps accessibility and maintainability."]]},
{subject:"htmlcss",title:"CSS box model",summary:"Every element is laid out as a rectangular box.",sections:[["Four parts","The content area holds text or media. Padding surrounds content. Border surrounds padding. Margin creates space outside the border."],["Example",' .card {\n  width: 300px;\n  padding: 20px;\n  border: 1px solid #ddd;\n  margin: 16px;\n  box-sizing: border-box;\n}'],["Tip","Using box-sizing: border-box makes the declared width include content, padding and border, which simplifies layout calculations."]]},
{subject:"javascript",title:"JavaScript variables and functions",summary:"Variables store references to values; functions package reusable logic.",sections:[["Declarations","Use const when a variable will not be reassigned. Use let when reassignment is needed. Avoid var in most modern code."],["Example",'const course = "JavaScript";\nlet lessons = 5;\nfunction describe(name) {\n  return `Welcome to ${name}`;\n}\nconsole.log(describe(course));'],["Functions","A function can accept parameters, perform statements and return a result. Arrow functions provide a shorter function syntax."]]},
{subject:"math",title:"Rank of a matrix",summary:"Rank is the maximum number of linearly independent rows or columns.",sections:[["Meaning","The rank of a matrix is the number of non-zero rows in its row-echelon form. Elementary row operations do not change rank."],["How to find rank","Convert the matrix to row-echelon form using row operations. Count the non-zero rows. That count is the rank."],["Example","If a matrix reduces to two non-zero rows and the remaining rows are all zero, its rank is 2. Rank helps determine consistency of systems of linear equations."]]},
{subject:"physics",title:"Simple harmonic motion",summary:"An oscillation where restoring acceleration is proportional to displacement and directed toward equilibrium.",sections:[["Definition","In ideal simple harmonic motion, acceleration is proportional to displacement from the mean position and acts in the opposite direction: a = −ω²x."],["Key terms","Amplitude is maximum displacement. Time period is time for one complete oscillation. Frequency is oscillations per second. Angular frequency is ω = 2πf."],["Examples","For small oscillations, a mass attached to an ideal spring performs SHM. A simple pendulum approximates SHM for small angular displacement."]]},
{subject:"chemistry",title:"Hardness of water",summary:"Hardness is mainly caused by dissolved calcium and magnesium salts.",sections:[["Types","Temporary hardness is commonly due to bicarbonates and can be removed by boiling. Permanent hardness is due to salts such as chlorides and sulphates."],["Treatment","Common methods include lime-soda treatment, zeolite process and ion-exchange process. The chosen method depends on water quality and application."],["Why it matters","Hard water can form scale in pipes and boilers and reduce soap lather. Water treatment improves suitability for domestic and industrial use."]]},
{subject:"computer",title:"Number systems",summary:"Computers represent data using binary digits.",sections:[["Bases","Binary has base 2 (0–1), octal base 8 (0–7), decimal base 10 (0–9) and hexadecimal base 16 (0–9 and A–F)."],["Decimal to binary","Repeatedly divide the decimal number by 2 and record each remainder. Read the remainders from bottom to top."],["Example","Decimal 13: 13÷2 = 6 remainder 1; 6÷2 = 3 remainder 0; 3÷2 = 1 remainder 1; 1÷2 = 0 remainder 1. Therefore 13₁₀ = 1101₂."]]},
{subject:"dbms",title:"Keys in relational databases",summary:"Keys identify rows and connect related tables.",sections:[["Primary key","A primary key uniquely identifies each row in a table. It cannot contain NULL values."],["Foreign key","A foreign key is a column or group of columns that references a candidate key, usually the primary key, in another table."],["Candidate and composite keys","A candidate key can uniquely identify a row. A composite key uses more than one column to identify a row."]]},
{subject:"english",title:"Formal email writing",summary:"A formal email is clear, polite and organised.",sections:[["Structure","Use a meaningful subject, suitable greeting, concise opening, clearly organised message, polite closing and your name."],["Tone","Use complete sentences and respectful language. Avoid slang, unnecessary abbreviations and overly long paragraphs."],["Quick checklist","Check recipient, subject, spelling, attachments and whether the requested action or deadline is clear."]]}
];

const questionBank = {
c:[
["Which function is the starting point of a standard C program?",["start()","main()","printf()","run()"],1,"Execution of a standard hosted C program begins at main()."],
["Which header is commonly used for printf()?",["stdlib.h","math.h","stdio.h","string.h"],2,"stdio.h declares standard input/output functions such as printf()."],
["Which operator gives the remainder?",["/","%","*","//"],1,"The modulus operator % gives the remainder for integer operands."],
["Which loop checks its condition before its first iteration?",["do-while","while","Both always run once","None"],1,"A while loop checks its condition before executing the body."],
["Which symbol ends a C statement?",[":",";",".",","],1,"A semicolon terminates most C statements."]
],
python:[
["Which keyword defines a function in Python?",["func","define","def","function"],2,"The def keyword starts a function definition."],
["Which type stores True or False?",["str","bool","int","list"],1,"bool is Python's Boolean type."],
["Which collection is ordered and mutable?",["tuple","set","list","frozenset"],2,"Lists are ordered and mutable."],
["What does len('code') return?",["3","4","5","Error"],1,"The string contains four characters."],
["Which block handles an exception?",["catch","except","error","finally only"],1,"An except clause handles matching exceptions in Python."]
],
htmlcss:[
["Which element is the main page heading?",["<head>","<h1>","<title>","<header>"],1,"h1 is the highest-level heading element."],
["Which attribute gives an image alternative text?",["src","href","alt","name"],2,"alt provides a text alternative for an image."],
["Which CSS property changes text colour?",["font-style","color","background","text-size"],1,"The color property sets the foreground text colour."],
["Which layout system is one-dimensional?",["CSS Grid","Flexbox","Table layout","Float"],1,"Flexbox is designed primarily for one-dimensional layout."],
["Which HTML element creates a hyperlink?",["<a>","<link>","<url>","<nav>"],0,"The anchor element creates hyperlinks using href."]
],
javascript:[
["Which keyword declares a block-scoped variable that can be reassigned?",["const","let","static","define"],1,"let declares a block-scoped, reassignable binding."],
["Which method selects an element by CSS selector?",["getHTML()","querySelector()","selectCSS()","findNode()"],1,"document.querySelector() returns the first matching element."],
["Which operator checks strict equality?",["=","==","===","!="],2,"=== compares value and type without coercion."],
["Which event commonly occurs when a button is pressed?",["change","click","load","submit only"],1,"A button press commonly triggers a click event."],
["Which method converts JSON text into a JavaScript value?",["JSON.parse()","JSON.stringify()","JSON.read()","parse.JSON()"],0,"JSON.parse() parses JSON text into a JavaScript value."]
],
math:[
["The rank of a zero matrix is:",["0","1","Number of rows","Undefined"],0,"A zero matrix has no non-zero rows in echelon form, so rank is zero."],
["The determinant of an identity matrix of order n is:",["0","1","n","−1"],1,"The identity matrix has all diagonal entries 1, so its determinant is 1."],
["The derivative of x² is:",["x","2x","x³","2"],1,"Using the power rule, d(x²)/dx = 2x."],
["The integral of 1 with respect to x is:",["0","x + C","1 + C","x² + C"],1,"The antiderivative of 1 is x plus a constant."],
["A square matrix is singular when its determinant is:",["1","Non-zero","0","Negative"],2,"A square matrix is singular if its determinant is zero."]
],
physics:[
["The SI unit of frequency is:",["metre","hertz","newton","joule"],1,"Frequency is measured in hertz (Hz), or cycles per second."],
["In SHM, acceleration is directed:",["Along displacement","Opposite displacement","Always upward","Always zero"],1,"The restoring acceleration is opposite to displacement."],
["Which phenomenon explains splitting of white light by a prism?",["Diffraction","Dispersion","Polarization","Reflection"],1,"Dispersion separates colours because refractive index varies with wavelength."],
["The SI unit of electric charge is:",["Ampere","Volt","Coulomb","Ohm"],2,"Electric charge is measured in coulombs."],
["A semiconductor generally has conductivity:",["Between conductor and insulator","Always zero","Greater than copper","Infinite"],0,"Semiconductors have electrical conductivity between conductors and insulators."]
],
chemistry:[
["Temporary hardness is mainly caused by:",["Bicarbonates of calcium and magnesium","Sodium chloride","Dissolved oxygen","Glucose"],0,"Calcium and magnesium bicarbonates are major causes of temporary hardness."],
["The pH of a neutral solution at 25°C is approximately:",["0","5","7","14"],2,"At 25°C, neutral pure water has pH close to 7."],
["Corrosion of iron is commonly called:",["Cracking","Rusting","Distillation","Polymerisation"],1,"Rusting is the corrosion of iron in the presence of oxygen and moisture."],
["A fuel cell converts chemical energy into:",["Only heat","Electrical energy","Sound","Nuclear energy"],1,"Fuel cells convert chemical energy directly into electrical energy."],
["Which is a polymer?",["Polyethylene","Sodium chloride","Copper","Water"],0,"Polyethylene is a polymer made from ethylene monomers."]
],
computer:[
["Binary number system has base:",["2","8","10","16"],0,"Binary uses two digits: 0 and 1."],
["1 byte contains:",["4 bits","8 bits","16 bits","32 bits"],1,"A byte is conventionally eight bits."],
["Which memory is volatile?",["ROM","RAM","SSD","DVD"],1,"RAM typically loses its contents when power is removed."],
["Which device is an output device?",["Keyboard","Mouse","Monitor","Scanner"],2,"A monitor presents visual output."],
["What does CPU stand for?",["Central Processing Unit","Computer Primary Utility","Control Program Unit","Central Print Unit"],0,"CPU stands for Central Processing Unit."]
],
dbms:[
["Which key uniquely identifies a row?",["Foreign key","Primary key","Duplicate key","Search key"],1,"A primary key uniquely identifies each row."],
["Which SQL command retrieves data?",["GET","SELECT","OPEN","FETCH ALL"],1,"SELECT retrieves rows from one or more tables."],
["What does DDL stand for?",["Data Definition Language","Data Display Logic","Database Design Link","Data Definition List"],0,"DDL defines database structures, for example CREATE and ALTER."],
["Which join returns matching rows from both tables?",["INNER JOIN","CROSS JOIN","FULL OUTER JOIN","SELF JOIN only"],0,"INNER JOIN returns rows where the join condition matches."],
["Which property means a transaction is all-or-nothing?",["Consistency","Isolation","Atomicity","Durability"],2,"Atomicity ensures a transaction fully succeeds or is rolled back."]
],
english:[
["Which is a suitable formal email greeting?",["Hey dude","Dear Professor","Yo","What's up"],1,"Dear Professor is a polite formal greeting."],
["Skimming is used to:",["Read every word slowly","Get the general idea quickly","Check spelling only","Memorise a paragraph"],1,"Skimming helps identify the overall idea quickly."],
["Which sentence has correct subject-verb agreement?",["She go to class.","She goes to class.","She going class.","She gone class."],1,"A singular third-person subject takes goes in the simple present."],
["A concise summary should:",["Add new opinions","Include every tiny detail","Present the main ideas briefly","Copy the whole passage"],2,"A summary captures the main ideas in fewer words."],
["Which is best for a formal email subject?",["Hi","Important!!!","Request for lab permission","Please read"],2,"A clear subject tells the recipient what the email concerns."]
]
};

const stateKey="cm_portal_v1";
let saved=JSON.parse(localStorage.getItem(stateKey)||'{"completed":{},"history":[],"name":"Student","theme":"light"}');
let activeSubject=null,practiceItems=[],practiceIndex=0,practiceChosen=null,practiceScore=0;
let testItems=[],testAnswers={},testIndex=0,testTimer=null,testSeconds=600,testSubject=null;
const $=id=>document.getElementById(id);
function persist(){localStorage.setItem(stateKey,JSON.stringify(saved));}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function toast(s){$("toast").textContent=s;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2300);}
function totalTopics(){return subjects.reduce((n,s)=>n+s.units.reduce((a,u)=>a+u[1].length,0),0);}
function doneTopics(){return Object.values(saved.completed).reduce((n,a)=>n+a.length,0);}
function subjectDone(id){return (saved.completed[id]||[]).length;}
function subjectTotal(s){return s.units.reduce((n,u)=>n+u[1].length,0);}
function pct(s){return Math.round(subjectDone(s.id)/subjectTotal(s)*100);}
function setPage(name){document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));$("page-"+name).classList.add("active");document.querySelectorAll(".side-link").forEach(b=>b.classList.toggle("active",b.dataset.page===name));const labels={dashboard:"Dashboard",subjects:"Subjects & syllabus",materials:"Reading materials",practice:"Practice quizzes",mock:"Mock tests",progress:"My progress"};$("crumb").textContent=labels[name];$("sidebar").classList.remove("open");window.scrollTo({top:0,behavior:"smooth"});if(name==="progress")renderProgress();}
document.addEventListener("click",e=>{const b=e.target.closest("[data-page]");if(b){e.preventDefault();setPage(b.dataset.page);}});
$("menuBtn").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
function subjectCard(s){return `<article class="subject-card"><div class="subject-top"><span class="subject-icon" style="background:${s.color}">${esc(s.symbol)}</span><span class="level-tag">${esc(s.level)}</span></div><h3>${esc(s.name)}</h3><p>${esc(s.desc)}</p><div class="subject-bottom"><span>${subjectTotal(s)} topics · ${pct(s)}% complete</span><button data-open-subject="${s.id}">View syllabus →</button></div></article>`;}
function renderSubjectCards(){ $("dashboardSubjects").innerHTML=subjects.slice(0,6).map(subjectCard).join("");$("allSubjects").innerHTML=subjects.map(subjectCard).join("");}
document.addEventListener("click",e=>{const b=e.target.closest("[data-open-subject]");if(b)openSubject(b.dataset.openSubject);});
function renderDashboard(){
 $("statSubjects").textContent=subjects.length;$("statTopics").textContent=doneTopics();const history=saved.history||[];$("statMocks").textContent=history.length;$("statBest").textContent=history.length?Math.max(...history.map(x=>x.score))+"%":"—";
 const inProgress=subjects.filter(s=>subjectDone(s.id)>0&&pct(s)<100).slice(0,2);const list=inProgress.length?inProgress:subjects.slice(0,2);
 $("continueCards").innerHTML=list.map(s=>`<div class="continue-item"><div class="mini-cover" style="background:${s.color}">${esc(s.symbol)}</div><div><b>${esc(s.name)}</b><small>${subjectDone(s.id)} / ${subjectTotal(s)} topics completed</small><div class="tiny-progress"><span style="width:${pct(s)}%"></span></div></div><button data-open-subject="${s.id}">Continue</button></div>`).join("");
 renderSubjectCards();
}
function openSubject(id){
 activeSubject=subjects.find(s=>s.id===id);if(!activeSubject)return;
 $("modalLevel").textContent=activeSubject.level.toUpperCase()+" · "+activeSubject.category.toUpperCase();$("modalSubjectTitle").textContent=activeSubject.name;$("modalDescription").textContent=activeSubject.desc;
 renderSubjectModal();$("subjectModal").classList.add("show");
}
function renderSubjectModal(){
 const s=activeSubject,done=subjectDone(s.id),total=subjectTotal(s);$("modalProgress").style.width=(done/total*100)+"%";$("modalProgressText").textContent=`${done} of ${total} topics completed`;
 $("unitList").innerHTML=s.units.map((u,i)=>`<div class="unit"><div class="unit-title"><span>Unit ${i+1}: ${esc(u[0])}</span><small>${u[1].filter((_,j)=>isDone(s.id,i,j)).length}/${u[1].length} complete</small></div><div class="topic-list">${u[1].map((t,j)=>`<div class="topic"><span>${isDone(s.id,i,j)?"✓":"○"}</span><span>${esc(t)}</span><button class="${isDone(s.id,i,j)?"done":""}" data-toggle-topic="${i}:${j}">${isDone(s.id,i,j)?"Completed":"Mark done"}</button></div>`).join("")}</div></div>`).join("");
}
function isDone(id,u,t){return (saved.completed[id]||[]).includes(`${u}-${t}`);}
document.addEventListener("click",e=>{const b=e.target.closest("[data-toggle-topic]");if(!b||!activeSubject)return;const [u,t]=b.dataset.toggleTopic.split("-").length===2?b.dataset.toggleTopic.split(":").map(Number):b.dataset.toggleTopic.split(":").map(Number);saved.completed[activeSubject.id]=saved.completed[activeSubject.id]||[];const key=`${u}-${t}`;const arr=saved.completed[activeSubject.id];if(arr.includes(key))saved.completed[activeSubject.id]=arr.filter(x=>x!==key);else arr.push(key);persist();renderSubjectModal();renderDashboard();toast("Your topic progress was updated.");});
$("closeSubject").addEventListener("click",()=>$("subjectModal").classList.remove("show"));
$("subjectModal").addEventListener("click",e=>{if(e.target===$("subjectModal"))$("subjectModal").classList.remove("show");});
$("subjectSearch").addEventListener("input",filterSubjects);$("levelSelect").addEventListener("change",filterSubjects);
function filterSubjects(){const q=$("subjectSearch").value.toLowerCase(),l=$("levelSelect").value;$("allSubjects").innerHTML=subjects.filter(s=>(s.name+" "+s.desc+" "+s.units.flat(2).join(" ")).toLowerCase().includes(q)&&(l==="all"||s.level===l)).map(subjectCard).join("")||"<p>No subjects found.</p>";}

function fillSubjectSelects(){
 const opts=subjects.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join("");$("materialSubject").innerHTML='<option value="all">All subjects</option>'+opts;$("practiceSubject").innerHTML=opts;
}
function renderMaterials(){
 const q=$("materialSearch").value.toLowerCase(),filter=$("materialSubject").value;
 const list=materials.filter(m=>(filter==="all"||m.subject===filter)&&(m.title+" "+m.summary).toLowerCase().includes(q));
 $("materialList").innerHTML=list.map((m,i)=>`<button class="material-item ${i===0?"active":""}" data-material="${materials.indexOf(m)}"><small>${esc(subjects.find(s=>s.id===m.subject)?.name||"Study note")}</small><b>${esc(m.title)}</b><small>${esc(m.summary)}</small></button>`).join("")||'<div class="panel">No reading materials match your search.</div>';
 if(list.length)showMaterial(materials.indexOf(list[0]));
}
function showMaterial(index){
 const m=materials[index];if(!m)return;
 document.querySelectorAll(".material-item").forEach(b=>b.classList.toggle("active",Number(b.dataset.material)===index));
 $("reader").innerHTML=`<span class="overline">${esc(subjects.find(s=>s.id===m.subject)?.name||"STUDY NOTE")}</span><h2>${esc(m.title)}</h2><p>${esc(m.summary)}</p>${m.sections.map(([h,p])=>`<h3>${esc(h)}</h3><p>${esc(p).replace(/\n/g,"<br>")}</p>`).join("")}<button class="btn secondary" data-open-subject="${m.subject}">Open full syllabus →</button>`;
}
document.addEventListener("click",e=>{const b=e.target.closest("[data-material]");if(b)showMaterial(Number(b.dataset.material));});
$("materialSearch").addEventListener("input",renderMaterials);$("materialSubject").addEventListener("change",renderMaterials);

function getQuestions(id){return questionBank[id]||[];}
function startPractice(){
 const id=$("practiceSubject").value;const pool=getQuestions(id);const count=Number($("practiceCount").value);practiceItems=pool.slice(0,count);practiceIndex=0;practiceChosen=null;practiceScore=0;renderPracticeQuestion();
}
$("startPractice").addEventListener("click",startPractice);
function renderPracticeQuestion(){
 const q=practiceItems[practiceIndex];if(!q)return;$("practicePanel").innerHTML=`<div class="quiz-head"><span>${esc(subjects.find(s=>s.id===$("practiceSubject").value).name)} · Question ${practiceIndex+1}/${practiceItems.length}</span><b>${practiceScore} correct</b></div><h3>${esc(q[0])}</h3><div class="quiz-options">${q[1].map((a,i)=>`<button class="quiz-option" data-practice-answer="${i}">${String.fromCharCode(65+i)}. ${esc(a)}</button>`).join("")}</div><div class="explanation" id="practiceExplanation"></div><div class="quiz-actions"><button class="btn secondary" id="practiceRestart">Restart</button><button class="btn primary" id="practiceNext" disabled>${practiceIndex===practiceItems.length-1?"Finish quiz":"Next question →"}</button></div>`;
 $("practicePanel").querySelectorAll("[data-practice-answer]").forEach(b=>b.addEventListener("click",()=>answerPractice(Number(b.dataset.practiceAnswer))));
 $("practicePanel").querySelector("#practiceRestart").addEventListener("click",startPractice);$("practicePanel").querySelector("#practiceNext").addEventListener("click",nextPractice);
}
function answerPractice(i){
 if(practiceChosen!==null)return;practiceChosen=i;const q=practiceItems[practiceIndex];if(i===q[2])practiceScore++;
 document.querySelectorAll("[data-practice-answer]").forEach((b,j)=>{if(j===q[2])b.classList.add("correct");else if(j===i)b.classList.add("incorrect");});
 $("practiceExplanation").textContent=(i===q[2]?"Correct. ":"Review: ")+q[3];$("practiceNext").disabled=false;
}
function nextPractice(){if(practiceChosen===null)return;if(practiceIndex<practiceItems.length-1){practiceIndex++;practiceChosen=null;renderPracticeQuestion();}else{$("practicePanel").innerHTML=`<div class="empty-state"><span>✓</span><h3>Practice complete</h3><p>You answered ${practiceScore} out of ${practiceItems.length} correctly (${Math.round(practiceScore/practiceItems.length*100)}%).</p><button class="btn primary" id="againPractice">Try again</button></div>`;$("againPractice").addEventListener("click",startPractice);}}

function renderMockCards(){
 $("mockGrid").innerHTML=subjects.map(s=>`<article class="mock-card"><span class="level-tag">${esc(s.level)}</span><h3>${esc(s.name)} mock test</h3><p>Test your understanding with ${getQuestions(s.id).length} multiple-choice questions.</p><div class="mock-meta"><span>10 minutes</span><span>${getQuestions(s.id).length} questions</span></div><button class="btn primary" data-start-test="${s.id}">Start mock test →</button></article>`).join("");
}
document.addEventListener("click",e=>{const b=e.target.closest("[data-start-test]");if(b)startTest(b.dataset.startTest);});
function startTest(id){
 stopTimer();testSubject=subjects.find(s=>s.id===id);testItems=[...getQuestions(id)];testAnswers={};testIndex=0;testSeconds=600;
 $("testPanel").classList.remove("hidden");$("testResult").classList.add("hidden");$("testSubjectLabel").textContent=testSubject.name.toUpperCase();$("testTitle").textContent=testSubject.name+" — Mock test";
 renderTestQuestion();startTimer();$("testPanel").scrollIntoView({behavior:"smooth",block:"start"});
}
function startTimer(){updateTimer();testTimer=setInterval(()=>{testSeconds--;updateTimer();if(testSeconds<=0){stopTimer();submitTest(true);}},1000);}
function stopTimer(){if(testTimer){clearInterval(testTimer);testTimer=null;}}
function updateTimer(){const mm=String(Math.floor(testSeconds/60)).padStart(2,"0"),ss=String(testSeconds%60).padStart(2,"0");$("timer").textContent=mm+":"+ss;$("timer").classList.toggle("warning",testSeconds<=60);}
function renderTestQuestion(){
 const q=testItems[testIndex];$("questionNumber").textContent=`Question ${testIndex+1} of ${testItems.length}`;$("answeredCount").textContent=Object.keys(testAnswers).length+" answered";$("testQuestion").textContent=q[0];$("testProgress").style.width=(Object.keys(testAnswers).length/testItems.length*100)+"%";
 $("testOptions").innerHTML=q[1].map((a,i)=>`<button class="test-option ${testAnswers[testIndex]===i?"selected":""}" data-test-answer="${i}">${String.fromCharCode(65+i)}. ${esc(a)}</button>`).join("");
 $("testOptions").querySelectorAll("[data-test-answer]").forEach(b=>b.addEventListener("click",()=>{testAnswers[testIndex]=Number(b.dataset.testAnswer);renderTestQuestion();}));
 $("questionNav").innerHTML=testItems.map((_,i)=>`<button class="qnum ${i===testIndex?"current":""} ${testAnswers[i]!==undefined?"answered":""}" data-qnav="${i}">${i+1}</button>`).join("");
 $("questionNav").querySelectorAll("[data-qnav]").forEach(b=>b.addEventListener("click",()=>{testIndex=Number(b.dataset.qnav);renderTestQuestion();}));
 $("prevQuestion").disabled=testIndex===0;$("nextQuestion").textContent=testIndex===testItems.length-1?"Review answers":"Next →";
}
$("prevQuestion").addEventListener("click",()=>{if(testIndex>0){testIndex--;renderTestQuestion();}});
$("nextQuestion").addEventListener("click",()=>{if(testIndex<testItems.length-1){testIndex++;renderTestQuestion();}else toast("Use the question numbers to review, then submit.");});
$("submitTest").addEventListener("click",()=>submitTest(false));
function submitTest(auto){
 stopTimer();let score=0;testItems.forEach((q,i)=>{if(testAnswers[i]===q[2])score++;});
 const percent=Math.round(score/testItems.length*100),attempt={subject:testSubject.name,score:percent,correct:score,total:testItems.length,date:new Date().toLocaleString("en-IN"),auto};
 saved.history.unshift(attempt);persist();$("testPanel").classList.add("hidden");$("testResult").classList.remove("hidden");
 $("testResult").innerHTML=`<span class="overline">MOCK TEST RESULT</span><div class="score-ring">${percent}%</div><h2>${percent>=80?"Excellent effort!":percent>=50?"Good practice!":"Keep practising!"}</h2><p>${esc(testSubject.name)} · ${score} correct out of ${testItems.length} · ${testItems.length-score} incorrect or unanswered</p><p>${auto?"The timer ended and your answers were submitted.":"Your test has been submitted."}</p><button class="btn primary" id="retryTest">Try again</button> <button class="btn secondary" id="backToMocks">Choose another test</button>`;
 $("retryTest").addEventListener("click",()=>startTest(testSubject.id));$("backToMocks").addEventListener("click",()=>{$("testResult").classList.add("hidden");});renderDashboard();renderProgress();$("testResult").scrollIntoView({behavior:"smooth"});
}

function renderProgress(){
 const total=totalTopics(),done=doneTopics(),hist=saved.history||[],avg=hist.length?Math.round(hist.reduce((n,x)=>n+x.score,0)/hist.length):0;
 $("progressOverview").innerHTML=`<div class="panel"><small>Topics completed</small><b>${done}/${total}</b><small>${Math.round(done/total*100)}% overall completion</small></div><div class="panel"><small>Mock tests attempted</small><b>${hist.length}</b><small>Keep testing your knowledge</small></div><div class="panel"><small>Average mock score</small><b>${hist.length?avg+"%":"—"}</b><small>Based on your saved attempts</small></div>`;
 $("progressRows").innerHTML=subjects.map(s=>`<div class="progress-row"><b>${esc(s.name)}</b><div class="bar"><span style="width:${pct(s)}%"></span></div><span>${pct(s)}%</span></div>`).join("");
 $("mockHistory").innerHTML=hist.length?hist.slice(0,12).map(h=>`<div class="history-row"><span><b>${esc(h.subject)}</b><br><small>${esc(h.date)}</small></span><b>${h.score}% (${h.correct}/${h.total})</b></div>`).join(""):'<p class="hint">No mock tests attempted yet. Start one from the Mock tests page.</p>';
}
$("editName").addEventListener("click",()=>{const name=prompt("Enter your display name:",saved.name||"Student");if(name&&name.trim()){saved.name=name.trim().slice(0,30);persist();renderProfile();}});
function renderProfile(){const n=saved.name||"Student";$("profileName").textContent=n;$("profileAvatar").textContent=n[0].toUpperCase();$("userChip").textContent=n[0].toUpperCase();}
$("themeBtn").addEventListener("click",()=>{document.body.classList.toggle("dark");saved.theme=document.body.classList.contains("dark")?"dark":"light";persist();$("themeBtn").textContent=saved.theme==="dark"?"☀":"☾";});
$("today").textContent=new Intl.DateTimeFormat("en-IN",{weekday:"short",day:"numeric",month:"short"}).format(new Date());
$("closeNote").addEventListener("click",()=>$("noteModal").classList.remove("show"));
document.addEventListener("keydown",e=>{if(e.key==="Escape"){document.querySelectorAll(".modal-backdrop").forEach(m=>m.classList.remove("show"));}});
if(saved.theme==="dark"){document.body.classList.add("dark");$("themeBtn").textContent="☀";}
renderProfile();fillSubjectSelects();renderDashboard();renderMaterials();renderMockCards();renderProgress();
